import asyncpg
import os

DB_URL = os.getenv("DATABASE_URL", "postgresql://user:password@localhost/stomatology_db")

async def create_db_pool():
    return await asyncpg.create_pool(DB_URL)

async def init_db(pool):
    async with pool.acquire() as conn:
        # Bemorlar jadvali
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id BIGINT PRIMARY KEY,
                full_name VARCHAR(255),
                phone_number VARCHAR(50)
            )
        ''')
        # Qabullar jadvali
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS appointments (
                id SERIAL PRIMARY KEY,
                user_id BIGINT REFERENCES users(user_id),
                doctor_id BIGINT,
                appointment_time TIMESTAMP WITH TIME ZONE,
                status VARCHAR(50) DEFAULT 'scheduled'
            )
        ''')
