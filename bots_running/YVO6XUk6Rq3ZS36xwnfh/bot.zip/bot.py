import asyncio
import os
import logging
from datetime import datetime, timedelta
from aiogram import Bot, Dispatcher, F, types
from aiogram.filters import CommandStart, Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ErrorEvent
from aiogram.client.default import DefaultBotProperties
from database import create_db_pool, init_db

BOT_TOKEN = os.getenv("BOT_TOKEN", "8863673291:AAGVDbBEWv_nmiw6ne0eYlUcKWogXo_00Qc")
DOCTOR_ID = int(os.getenv("DOCTOR_ID", "8453381252"))

logging.basicConfig(level=logging.INFO)
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode="Markdown"))
dp = Dispatcher()

@dp.error()
async def global_error_handler(event: ErrorEvent):
    logging.error(f"Kritik xatolik yuz berdi: {event.exception}", exc_info=True)
    return True

def get_doctor_keyboard(appointment_id: int):
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⏳ Keyinroqqa surish", callback_data=f"reschedule_{appointment_id}")]
    ])

@dp.message(CommandStart())
async def start_cmd(message: types.Message):
    await message.answer("Assalomu alaykum! Stomatologiya botimizga xush kelibsiz.")

@dp.message(Command("qabul"))
async def create_appointment(message: types.Message):
    user_id = message.from_user.id
    full_name = message.from_user.full_name
    phone = "+998901234567"
    
    appointment_time = datetime.now() + timedelta(days=2)
    
    async with dp["db_pool"].acquire() as conn:
        await conn.execute(
            "INSERT INTO users (user_id, full_name, phone_number) VALUES ($1, $2, $3) ON CONFLICT (user_id) DO NOTHING",
            user_id, full_name, phone
        )
        app_id = await conn.fetchval(
            "INSERT INTO appointments (user_id, doctor_id, appointment_time) VALUES ($1, $2, $3) RETURNING id",
            user_id, DOCTOR_ID, appointment_time
        )

    await message.answer(f"Sizning qabulingiz ro'yxatga olindi: {appointment_time.strftime('%Y-%m-%d %H:%M')}")
    
    doctor_text = (
        f"🔴 **Yangi qabul!**\n\n"
        f"Bemor: {full_name}\n"
        f"Tel: {phone}\n"
        f"Vaqti: {appointment_time.strftime('%Y-%m-%d %H:%M')}"
    )
    await bot.send_message(DOCTOR_ID, doctor_text, reply_markup=get_doctor_keyboard(app_id))

@dp.callback_query(F.data.startswith("reschedule_"))
async def reschedule_handler(callback: types.CallbackQuery):
    app_id = int(callback.data.split("_")[1])
    
    new_time = datetime.now() + timedelta(days=4)
    
    async with dp["db_pool"].acquire() as conn:
        row = await conn.fetchrow(
            "UPDATE appointments SET appointment_time = $1 WHERE id = $2 RETURNING user_id",
            new_time, app_id
        )
        user_id = row["user_id"] if row else None

    await callback.message.edit_text(
        f"{callback.message.text}\n\n✅ **Qabul vaqti {new_time.strftime('%Y-%m-%d %H:%M')} ga ko'chirildi.**"
    )
    
    if user_id:
        user_text = (
            f"Hurmatli bemor, sizning qabul vaqtingiz shifokor tomonidan "
            f"**{new_time.strftime('%Y-%m-%d %H:%M')}** ga ko'chirildi."
        )
        await bot.send_message(user_id, user_text)
        
    await callback.answer("Vaqt ko'chirildi!")

async def main():
    pool = await create_db_pool()
    await init_db(pool)
    dp["db_pool"] = pool
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())