from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from config import BOT_USERNAME
import profile_clock


def main_menu_kb(connected: bool = False, is_admin: bool = False) -> InlineKeyboardMarkup:
    if connected:
        # Foydalanuvchi botni akkauntiga ulagan — "Botni ulash" o'rniga
        # avto-javoblar ro'yxatiga tezkor kirish beramiz.
        rows = [
            [InlineKeyboardButton("🧾 Buyruqlar", callback_data="menu:commands"),
             InlineKeyboardButton("📘 Qo'llanma", callback_data="menu:guide")],
            [InlineKeyboardButton("👤 Profilim", callback_data="menu:profile"),
             InlineKeyboardButton("⚙️ Sozlamalar", callback_data="menu:settings")],
            [InlineKeyboardButton("💬 Avto javoblar ro'yxati", callback_data="menu:autoreplies")],
            [InlineKeyboardButton("👥 Mijozlar", callback_data="menu:contacts")],
        ]
    else:
        rows = [
            [InlineKeyboardButton("🔗 Botni ulash", callback_data="menu:connect"),
             InlineKeyboardButton("📘 Qo'llanma", callback_data="menu:guide")],
            [InlineKeyboardButton("🧾 Buyruqlar", callback_data="menu:commands"),
             InlineKeyboardButton("👤 Profilim", callback_data="menu:profile")],
            [InlineKeyboardButton("⚙️ Sozlamalar", callback_data="menu:settings")],
        ]
    if is_admin:
        # Admin bo'lsa, /admin buyrug'ini qo'lda yozish shart bo'lmasin
        # deb, bosh menyuning eng pastiga alohida tugma qo'shamiz — shu
        # orqali "Premium emoji" va boshqa admin bo'limlariga bir bosishda
        # o'tiladi.
        rows.append([InlineKeyboardButton("🛠 Admin panel", callback_data="admin:home")])
    return InlineKeyboardMarkup(rows)


def back_kb(target: str = "menu:home") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("↩️ Orqaga", callback_data=target)]])


def profile_kb(current_tariff: str) -> InlineKeyboardMarkup:
    is_pro = current_tariff == "pro"
    rows = [[
        InlineKeyboardButton(
            "🆓 Bepul" + ("" if is_pro else " ✅"), callback_data="tariff:info:free"
        ),
        InlineKeyboardButton(
            "💎 Pro" + (" ✅" if is_pro else ""),
            callback_data=("tariff:info:pro" if is_pro else "menu:buy_pro"),
        ),
    ]]
    rows.append([InlineKeyboardButton("💰 Balansni to'ldirish", callback_data="menu:balance")])
    rows.append([InlineKeyboardButton("👥 Taklif havola", callback_data="menu:referral")])
    rows.append([InlineKeyboardButton("↩️ Orqaga", callback_data="menu:home")])
    return InlineKeyboardMarkup(rows)


def buy_pro_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💳 Karta orqali to'lash", callback_data="pro:buy:card")],
        [InlineKeyboardButton("⭐ Stars orqali to'lash", callback_data="pro:buy:stars")],
        [InlineKeyboardButton("↩️ Orqaga", callback_data="menu:profile")],
    ])


def admin_emoji_kb(emoji_map: dict) -> InlineKeyboardMarkup:
    """Premium emoji boshqaruvi: mavjud moslamalar + yangi qo'shish."""
    rows = []
    for char, cid in emoji_map.items():
        short = cid[-6:] if len(cid) > 6 else cid
        rows.append([
            InlineKeyboardButton(
                f"{char}  →  ...{short}  🗑",
                callback_data=f"emoji:del:{char}"
            )
        ])
    rows.append([InlineKeyboardButton("➕ Yangi emoji qo'shish", callback_data="emoji:add")])
    rows.append([InlineKeyboardButton("↩️ Orqaga", callback_data="admin:home")])
    return InlineKeyboardMarkup(rows)


def balance_methods_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💳 Avto to'lov (karta)", callback_data="balance:card")],
        [InlineKeyboardButton("⭐ Avto to'lov (stars)", callback_data="balance:stars")],
        [InlineKeyboardButton("↩️ Orqaga", callback_data="menu:profile")],
    ])


def invoice_kb(amount: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📋 Summani nusxalash", callback_data=f"copy:amount:{amount}")],
        [InlineKeyboardButton("📋 Kartani nusxalash", callback_data="copy:card")],
        [
            InlineKeyboardButton("❌ Orqaga", callback_data="menu:balance"),
            InlineKeyboardButton("✅ Tasdiqlash", callback_data=f"pay:confirm:{amount}"),
        ],
    ])


def connect_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("⚙️ Sozlamalarni ochish", url="tg://settings/edit")],
        [InlineKeyboardButton("✅ Ulanganini tekshirish", callback_data="connect:check")],
        [InlineKeyboardButton("↩️ Orqaga", callback_data="menu:home")],
    ])


def settings_kb(user) -> InlineKeyboardMarkup:
    s = user.settings
    is_pro = user.tariff == "pro"
    rows = []
    if is_pro:
        rows.append([
            InlineKeyboardButton("⏰ Profilga soat", callback_data="menu:soat"),
            InlineKeyboardButton(f"🟢 24/7 online: {'on' if s.online_24_7 else 'off'}",
                                  callback_data="set:online_24_7"),
        ])
    rows.append([InlineKeyboardButton("✉️ «.ok» so'zini o'zgartirish", callback_data="set:ok_text")])
    rows.append([InlineKeyboardButton("📍 «.loc» so'zini o'zgartirish", callback_data="set:loc_text")])
    if is_pro:
        rows.append([InlineKeyboardButton(f"🕵️ Shpion rejimi: {'on' if s.spy_mode else 'off'}",
                                           callback_data="set:spy_mode")])
    else:
        rows.append([InlineKeyboardButton(
            "🔒 Pro funksiyalar (soat, online, shpion)", callback_data="menu:buy_pro"
        )])
    rows.append([InlineKeyboardButton("🐥 Chatbotni sozlash", callback_data="menu:chatbot_settings")])
    rows.append([InlineKeyboardButton("↩️ Orqaga", callback_data="menu:home")])
    return InlineKeyboardMarkup(rows)


def spy_consent_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Roziman", callback_data="spyconsent:yes"),
         InlineKeyboardButton("❌ Rad etish", callback_data="spyconsent:no")],
    ])


def chatbot_settings_kb(user) -> InlineKeyboardMarkup:
    s = user.settings
    mode_label = "🔂 Faqat 1 marta" if s.autoreply_mode == "once" else "♾️ Har doim"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"🔁 Avto-javob rejimi: {mode_label}", callback_data="cbset:autoreply_mode")],
        [InlineKeyboardButton("♻️ \"Yuborilgan\" ro'yxatini tozalash", callback_data="cbset:reset_autoreply")],
        [InlineKeyboardButton(f"⏰ Ish vaqti: {'on' if s.work_hours_enabled else 'off'} "
                               f"({s.work_hours_start}–{s.work_hours_end})",
                               callback_data="cbset:work_hours_enabled")],
        [InlineKeyboardButton("🕘 Ish vaqtini o'zgartirish", callback_data="cbtext:work_hours_range")],
        [InlineKeyboardButton("🌙 Ish vaqtidan tashqari matn", callback_data="cbtext:after_hours_text")],
        [InlineKeyboardButton("🔑 Kalit so'zli javoblar", callback_data="menu:keywords")],
        [InlineKeyboardButton(f"✏️ Tahrirlanish: {'on' if s.edit_notify else 'off'}",
                               callback_data="cbset:edit_notify"),
         InlineKeyboardButton(f"🗑 O'chirishlar: {'on' if s.delete_notify else 'off'}",
                               callback_data="cbset:delete_notify")],
        [InlineKeyboardButton(f"🤖 APK o'chirish: {'on' if s.apk_autodelete else 'off'}",
                               callback_data="cbset:apk_autodelete"),
         InlineKeyboardButton(f"⌨️ Yozmoqda: {'on' if s.typing_notify else 'off'}",
                               callback_data="cbset:typing_notify")],
        [InlineKeyboardButton("✏️ Tahrirlash matnini o'zgartirish", callback_data="cbtext:edit_notify_text")],
        [InlineKeyboardButton("🗑 O'chirish matnini o'zgartirish", callback_data="cbtext:delete_notify_text")],
        [InlineKeyboardButton("↩️ Orqaga", callback_data="menu:settings")],
    ])


def soat_kb(user) -> InlineKeyboardMarkup:
    """«Profilga soat» sozlamalari — rasmdagi kabi: on/off, 6 ta shrift
    uslubi (joriy vaqt namunasi bilan) va ajratuvchi «|» tugmasi."""
    s = user.settings
    main_toggle = InlineKeyboardButton(
        f"⏰ Profilga soat: {'off ❌' if not s.profil_soat else 'on ✅'}",
        callback_data="soat:toggle",
    )

    font_rows = []
    keys = list(profile_clock.FONT_STYLES.keys())
    for i in range(0, len(keys), 3):
        row = []
        for key in keys[i:i + 3]:
            label = profile_clock.preview(key)
            if key == s.soat_font:
                label += " ✅"
            row.append(InlineKeyboardButton(label, callback_data=f"soat:font:{key}"))
        font_rows.append(row)

    sep_row = [InlineKeyboardButton(
        f"Ajratuvchi «|»: {'on' if s.soat_sep else 'off'}", callback_data="soat:sep",
    )]

    rows = [[main_toggle], *font_rows, sep_row, [InlineKeyboardButton("↩️ Orqaga", callback_data="menu:settings")]]
    return InlineKeyboardMarkup(rows)


def autoreplies_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("↩️ Orqaga", callback_data="menu:home")],
    ])


# ============================================================================
#                            🛠 ADMIN PANEL
# ============================================================================

def admin_menu_kb(pending: int = 0, banned: int = 0) -> InlineKeyboardMarkup:
    pending_label = f"⏳ To'lovlar ({pending})" if pending else "⏳ To'lovlar"
    banned_label = f"🚫 Bloklanganlar ({banned})" if banned else "🚫 Bloklanganlar"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 Statistika", callback_data="admin:stats"),
         InlineKeyboardButton("📈 Hisobot", callback_data="admin:report")],
        [InlineKeyboardButton("👥 Foydalanuvchilar", callback_data="admin:users"),
         InlineKeyboardButton(banned_label, callback_data="admin:banned")],
        [InlineKeyboardButton(pending_label, callback_data="admin:pending"),
         InlineKeyboardButton("🧾 Loglar", callback_data="admin:logs")],
        [InlineKeyboardButton("📢 Broadcast", callback_data="admin:broadcast")],
        [InlineKeyboardButton("🎨 Premium emoji", callback_data="admin:emoji"),
         InlineKeyboardButton("💎 Pro tarif berish", callback_data="admin:givepro")],
    ])


def admin_user_kb(user) -> InlineKeyboardMarkup:
    ban_btn = (
        InlineKeyboardButton("✅ Blokdan chiqarish", callback_data=f"admin:unban:{user.user_id}")
        if user.is_banned else
        InlineKeyboardButton("🚫 Bloklash", callback_data=f"admin:ban:{user.user_id}")
    )
    pro_btn = (
        InlineKeyboardButton("❌ Proni bekor qilish", callback_data=f"admin:removepro:{user.user_id}")
        if user.tariff == "pro" else
        InlineKeyboardButton("💎 Pro berish (30 kun)", callback_data=f"admin:giveprouser:{user.user_id}")
    )
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💰 Balans qo'shish", callback_data=f"admin:addbal:{user.user_id}")],
        [pro_btn],
        [InlineKeyboardButton("♻️ Avto-javob xotirasini tozalash",
                               callback_data=f"admin:resetauto:{user.user_id}")],
        [ban_btn],
        [InlineKeyboardButton("↩️ Orqaga", callback_data="admin:users")],
    ])


def admin_back_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("↩️ Admin panelga qaytish", callback_data="admin:home")],
    ])


def admin_cancel_kb() -> InlineKeyboardMarkup:
    """Admin biror narsa yozishi kutilayotganda (ID, summa, broadcast matni)
    ko'rsatiladi — 'orqaga' emas, aynan 'bekor qilish' deb nomlanadi, chunki
    bu holatda admin hali hech qayerga kirmagan, faqat kiritishni bekor
    qilmoqchi."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("❌ Bekor qilish", callback_data="admin:home")],
    ])


def admin_ban_confirm_kb(user_id: int) -> InlineKeyboardMarkup:
    """Bloklash — qaytarib bo'lmaydigan (foydalanuvchi tajribasiga jiddiy
    ta'sir qiluvchi) amal, shuning uchun bitta bosishda emas, tasdiqlash
    orqali bajariladi."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🚫 Ha, bloklash", callback_data=f"admin:banconfirm:{user_id}"),
         InlineKeyboardButton("❌ Bekor qilish", callback_data=f"admin:cancelban:{user_id}")],
    ])


def admin_broadcast_confirm_kb() -> InlineKeyboardMarkup:
    """Hammaga xabar yuborishdan oldingi so'nggi tasdiq — xatolik bilan
    noto'g'ri matn butun foydalanuvchi bazasiga ketib qolmasligi uchun."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📢 Ha, hammaga yuborish", callback_data="admin:broadcast_send")],
        [InlineKeyboardButton("❌ Bekor qilish", callback_data="admin:broadcast_cancel")],
    ])


def admin_list_page_kb(page_prefix: str, offset: int, has_more: bool) -> InlineKeyboardMarkup:
    """Uzun ro'yxatlar (bloklanganlar, loglar) uchun 'Yana ko'rsatish'
    tugmasi bilan sahifalash."""
    rows = []
    if has_more:
        rows.append([InlineKeyboardButton(
            "➡️ Yana ko'rsatish", callback_data=f"admin:{page_prefix}:{offset}"
        )])
    rows.append([InlineKeyboardButton("↩️ Admin panelga qaytish", callback_data="admin:home")])
    return InlineKeyboardMarkup(rows)


# ============================================================================
#                            👥 MIJOZLAR
# ============================================================================

def contacts_list_kb(contacts) -> InlineKeyboardMarkup:
    rows = []
    for c in contacts:
        label = c['name'] or str(c['chat_id'])
        if c['tag']:
            label += f" [{c['tag']}]"
        rows.append([InlineKeyboardButton(label, callback_data=f"contact:{c['chat_id']}")])
    rows.append([InlineKeyboardButton("↩️ Orqaga", callback_data="menu:home")])
    return InlineKeyboardMarkup(rows)


def contact_card_kb(chat_id: int) -> InlineKeyboardMarkup:
    tags = ["🆕 Yangi", "🔥 Qiziqmoqda", "😴 Qiziqmagan", "⭐ VIP"]
    tag_row = [InlineKeyboardButton(t, callback_data=f"contact_tag:{chat_id}:{t}") for t in tags[:2]]
    tag_row2 = [InlineKeyboardButton(t, callback_data=f"contact_tag:{chat_id}:{t}") for t in tags[2:]]
    return InlineKeyboardMarkup([
        tag_row,
        tag_row2,
        [InlineKeyboardButton("📝 Izoh yozish", callback_data=f"contact_note:{chat_id}")],
        [InlineKeyboardButton("↩️ Orqaga", callback_data="menu:contacts")],
    ])


# ============================================================================
#                       🔑 KALIT SO'ZLI JAVOBLAR
# ============================================================================

def keywords_kb(rows) -> InlineKeyboardMarkup:
    kb_rows = []
    for r in rows:
        kb_rows.append([
            InlineKeyboardButton(f"🗑 {r['keyword']}", callback_data=f"kwdel:{r['id']}"),
        ])
    kb_rows.append([InlineKeyboardButton("➕ Yangi qo'shish", callback_data="kwadd")])
    kb_rows.append([InlineKeyboardButton("↩️ Orqaga", callback_data="menu:chatbot_settings")])
    return InlineKeyboardMarkup(kb_rows)
