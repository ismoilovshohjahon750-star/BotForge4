
# CloudBot Auto-injected Global Error Handler
async def _cloudbot_error_handler(update, context):
    if not context.error:
        return
    err_str = str(context.error)
    err_type = type(context.error).__name__
    transient = ('httpx.ReadError', 'httpx.ConnectError', 'httpx.RemoteProtocolError', 'httpx.ReadTimeout', 'httpx.ConnectTimeout', 'httpx.TimeoutException', 'ReadError', 'ConnectError', 'RemoteProtocolError', 'ReadTimeout', 'ConnectTimeout', 'TimeoutException', 'TimedOut', 'NetworkError', 'RetryAfter')
    if any(t in err_str or t in err_type for t in transient):
        return
    import logging
    logging.warning(f"Bot handler notice: {context.error}")

"""
ArdoChat Bot — HAQIQIY to'lovlar.

Uch xil real yo'l qo'llab-quvvatlanadi:

1) Telegram Stars (currency="XTR") — Telegram'ning o'z ichki valyutasi,
   hech qanday tashqi provayder kerak emas, darhol va avtomatik ishlaydi.

2) Click / Payme / Uzcard orqali karta to'lovi — agar .env faylida
   PAYMENT_PROVIDER_TOKEN to'ldirilgan bo'lsa (uni @BotFather -> Payments
   bo'limidan Click yoki Payme'ni ulab olasiz), to'lov to'liq avtomatik va
   real vaqtda amalga oshadi (pre_checkout_query + successful_payment).

3) Agar provider token yo'q bo'lsa — foydalanuvchiga karta raqami
   ko'rsatiladi, u pul o'tkazadi, so'rov ADMIN'ga yuboriladi va admin
   tugma bosib tasdiqlaganda balans HAQIQIY va DOIMIY (SQLite) tarzda
   kredit qilinadi. Bu — real hayotda ko'plab kichik botlar ishlatadigan,
   to'liq ishlaydigan usul (merchant API bo'lmasa ham).
"""
import random

from telegram import Update, LabeledPrice, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes

from config import PAYMENT_PROVIDER_TOKEN, ADMIN_ID, CARD_NUMBER, CARD_OWNER, SMS_PAYMENT_MATCH_MIN, SMS_PAYMENT_MATCH_MAX
from storage import storage


def _pick_unique_pay_amount(base_amount: int) -> int:
    """`base_amount`ga tasodifiy 'moslik kodi' (masalan 50-999 oralig'ida)
    qo'shib, hozir kutilayotgan boshqa so'rovlar bilan TO'QNASHMAYDIGAN
    summa hosil qiladi. Shu orqali SMS'da kelgan "1 250 so'm" degan summa,
    aynan bitta foydalanuvchining bitta so'roviga mos ekanini bilib olamiz."""
    taken = set(storage.pending_pay_amounts(method="card"))
    for _ in range(200):
        candidate = base_amount + random.randint(SMS_PAYMENT_MATCH_MIN, SMS_PAYMENT_MATCH_MAX)
        if candidate not in taken:
            return candidate
    return base_amount + random.randint(SMS_PAYMENT_MATCH_MIN, SMS_PAYMENT_MATCH_MAX)


async def send_stars_invoice(update: Update, context: ContextTypes.DEFAULT_TYPE, stars_amount: int):
    chat_id = update.effective_chat.id
    await context.bot.send_invoice(
        chat_id=chat_id,
        title="ArdoChat Bot — Stars balans",
        description=f"{stars_amount} \u2b50 hisobingizga qo'shiladi.",
        payload=f"stars_topup:{stars_amount}",
        provider_token="",
        currency="XTR",
        prices=[LabeledPrice(label=f"{stars_amount} Stars", amount=stars_amount)],
    )


async def send_card_invoice(update: Update, context: ContextTypes.DEFAULT_TYPE, amount_som: int):
    chat_id = update.effective_chat.id
    await context.bot.send_invoice(
        chat_id=chat_id,
        title="ArdoChat Bot — Balansni to'ldirish",
        description=f"Balansingizga {amount_som:,} so'm qo'shiladi.".replace(",", " "),
        payload=f"card_topup:{amount_som}",
        provider_token=PAYMENT_PROVIDER_TOKEN,
        currency="UZS",
        prices=[LabeledPrice(label="Balans to'ldirish", amount=amount_som * 100)],
        need_email=False,
        need_phone_number=False,
    )


async def pre_checkout_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.pre_checkout_query
    await query.answer(ok=True)


async def successful_payment_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    payment = update.message.successful_payment
    user_id = update.effective_user.id
    payload = payment.invoice_payload

    if payload.startswith("stars_topup:"):
        stars = int(payload.split(":")[1])
        storage.add_balance_stars(user_id, stars)
        await update.message.reply_text(
            f"\u2705 To'lov muvaffaqiyatli! {stars} \u2b50 balansingizga qo'shildi."
        )
    elif payload.startswith("card_topup:"):
        amount = int(payload.split(":")[1])
        storage.add_balance_som(user_id, amount)
        await update.message.reply_text(
            f"\u2705 To'lov muvaffaqiyatli! {amount:,} so'm balansingizga qo'shildi.".replace(",", " ")
        )


async def request_manual_card_topup(update: Update, context: ContextTypes.DEFAULT_TYPE, amount: int):
    user = update.effective_user
    pay_amount = _pick_unique_pay_amount(amount)
    topup_id = storage.create_topup(user.id, amount, "card", pay_amount=pay_amount)

    from sms_payment import sms_enabled_for  # aylanma import'dan qochish uchun shu yerda
    auto_note = (
        "\n\U0001f7e2 <i>Aynan shu summani o'tkazing — to'lov avtomatik aniqlanadi.</i>"
        if sms_enabled_for(ADMIN_ID) else
        "\n\u2139\ufe0f <i>To'lov chekini (screenshot) yuborsangiz, admin tekshirib tasdiqlaydi.</i>"
    )

    await update.message.reply_text(
        "\U0001f4b3 To'lov ma'lumotlari:\n\n"
        f"\U0001f4b5 Summa: <b>{pay_amount:,} so'm</b>\n".replace(",", " ") +
        f"\U0001f4b3 Karta: <code>{CARD_NUMBER}</code>\n"
        f"\U0001f464 Egasi: {CARD_OWNER}\n"
        f"{auto_note}\n\n"
        "\u26a0\ufe0f <b>Aynan ko'rsatilgan summani</b> o'tkazing (tiyin/so'migacha) — "
        "boshqa summa yuborilsa avtomatik aniqlanmaydi.\n\n"
        f"So'rov raqami: #{topup_id}",
        parse_mode=ParseMode.HTML,
    )

    if ADMIN_ID:
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("\u2705 Tasdiqlash", callback_data=f"admin_topup:approve:{topup_id}"),
            InlineKeyboardButton("\u274c Rad etish", callback_data=f"admin_topup:reject:{topup_id}"),
        ]])
        await context.bot.send_message(
            chat_id=ADMIN_ID,
            text=(
                f"\U0001f514 Yangi to'lov so'rovi #{topup_id}\n\n"
                f"\U0001f464 Foydalanuvchi: {user.first_name} (id: <code>{user.id}</code>)\n"
                f"\U0001f4b5 Summa: {amount:,} so'm".replace(",", " ")
            ),
            reply_markup=kb,
            parse_mode=ParseMode.HTML,
        )
    else:
        await update.message.reply_text(
            "\u26a0\ufe0f Admin ID sozlanmagan (.env dagi ADMIN_ID). "
            "To'lovni tasdiqlash uchun ADMIN_ID ni to'ldiring."
        )


async def admin_topup_decision(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    if ADMIN_ID and update.effective_user.id != ADMIN_ID:
        await query.answer("Bu tugma faqat admin uchun.", show_alert=True)
        return

    _, action, topup_id_str = query.data.split(":")
    topup_id = int(topup_id_str)
    topup = storage.get_topup(topup_id)

    if topup is None or topup['status'] != "pending":
        await query.answer("Bu so'rov allaqachon ko'rib chiqilgan.", show_alert=True)
        return

    if action == "approve":
        storage.add_balance_som(topup['user_id'], topup['amount'])
        storage.set_topup_status(topup_id, "approved")
        await query.edit_message_text(
            query.message.text + "\n\n\u2705 TASDIQLANDI — balans kreditlandi."
        )
        await context.bot.send_message(
            chat_id=topup['user_id'],
            text=(
                f"\u2705 To'lovingiz tasdiqlandi! {topup['amount']:,} so'm "
                "balansingizga qo'shildi.".replace(",", " ")
            ),
        )
    else:
        storage.set_topup_status(topup_id, "rejected")
        await query.edit_message_text(query.message.text + "\n\n\u274c RAD ETILDI.")
        await context.bot.send_message(
            chat_id=topup['user_id'],
            text=f"\u274c To'lov so'rovingiz (#{topup_id}) rad etildi. Admin bilan bog'laning.",
        )
