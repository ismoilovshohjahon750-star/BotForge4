
# CloudBot Auto-injected Global Error Handler
async def _cloudbot_error_handler(update, context):
    if not context.error:
        return
    err_str = str(context.error)
    err_type = type(context.error).__name__
    transient = ('httpx.ReadError', 'httpx.ConnectError', 'httpx.RemoteProtocolError', 'httpx.ReadTimeout', 'httpx.ConnectTimeout', 'httpx.TimeoutException', 'ReadError', 'ConnectError', 'RemoteProtocolError', 'ReadTimeout', 'ConnectTimeout', 'TimeoutException', 'TimedOut', 'NetworkError', 'RetryAfter')
    if any(t in err_str or t in err_type for t in transient):
        return
    import logging
    logging.warning(f"Bot handler notice: {context.error}")

"""
ArdoChat Bot — HAQIQIY Telegram Business ulanish va avto-javob.
Bu demo emas: foydalanuvchi telefonida
  Sozlamalar > Telegram Business > Chatbots > @ArdoChat_Bot
qo'shsa, Telegram bizning botimizga `business_connection` update yuboradi
va shu foydalanuvchining hisobiga kelgan xabarlarni `business_message`
update sifatida uzatadi. Biz esa `send_message(business_connection_id=...)`
orqali xuddi o'sha odam nomidan (Business hisobi orqali) javob yozamiz.
Talab: bu funksiya faqat Telegram Business obunasi (Premium orqali)
bo'lgan akkauntlarda ishlaydi — bu Telegram tomonidan qo'yilgan cheklov,
kod tomondan hech qanday cheklov yo'q.
"""
import asyncio
import html as _html
import logging
import random
import re
import time
from collections import OrderedDict
from datetime import datetime
from datetime import time as time_cls
import httpx
from telegram import Update
from telegram.ext import ContextTypes
from telegram.ext.filters import UpdateFilter
import texts
import keyboards
from storage import storage
from config import ADMIN_ID
logger = logging.getLogger(__name__)
class DeletedBusinessMessagesFilter(UpdateFilter):
    """python-telegram-bot'ning tayyor filters.UpdateType'ida
    deleted_business_messages uchun filter yo'q (faqat business_message va
    edited_business_message bor) — shuning uchun o'zimiz yozamiz."""
    def filter(self, update: Update) -> bool:
        return update.deleted_business_messages is not None
# "Faqat 1 marta" rejimi endi storage (SQLite) orqali ishlaydi — bot qayta
# ishga tushirilsa ham unutilmaydi (pastdagi storage.has_autoreply_sent /
# mark_autoreply_sent). Bu yerdagi xotira-ichi lug'at faqat "Har doim"
# rejimida bitta xabarni Telegram tomonidan ikki marta yuborib
# yuborilishining oldini olish uchun — (owner_id, chat_id, message_id) -> True.
_recent_message_ids: "OrderedDict[tuple[int, int, int], bool]" = OrderedDict()
_RECENT_MESSAGE_IDS_MAX = 5000
# Tahrirlash/o'chirish bildirishnomalarini spam qilib yubormaslik uchun
# oxirgi yuborilgan vaqt: (owner_id, chat_id, "edit"/"delete") -> monotonic vaqt
_last_notify_at: dict[tuple[int, int, str], float] = {}
_NOTIFY_COOLDOWN = 5.0  # soniya
# (connection_id, message_id) -> xabar kimdan kelgani (True = egasi o'zi).
# "O'chirilgan xabar" update'ida from_user bo'lmaydi, shuning uchun buni
# xabar kelganda oldindan eslab qolamiz. Xotira portlab ketmasligi uchun
# hajmi cheklangan (eng eskisi avtomatik o'chadi).
_owner_flag_cache: "OrderedDict[tuple[str, int], bool]" = OrderedDict()
_OWNER_FLAG_CACHE_MAX = 5000
def _cache_owner_flag(connection_id: str, message_id: int, is_owner: bool):
    key = (connection_id, message_id)
    _owner_flag_cache[key] = is_owner
    _owner_flag_cache.move_to_end(key)
    while len(_owner_flag_cache) > _OWNER_FLAG_CACHE_MAX:
        _owner_flag_cache.popitem(last=False)
def _pop_owner_flag(connection_id: str, message_id: int) -> bool:
    return _owner_flag_cache.pop((connection_id, message_id), False)
def _notify_allowed(owner_id: int, chat_id: int, kind: str) -> bool:
    key = (owner_id, chat_id, kind)
    now = time.monotonic()
    last = _last_notify_at.get(key)
    if last is not None and (now - last) < _NOTIFY_COOLDOWN:
        return False
    _last_notify_at[key] = now
    return True
def _is_apk(msg) -> bool:
    doc = msg.document
    if not doc:
        return False
    if doc.mime_type == "application/vnd.android.package-archive":
        return True
    name = (doc.file_name or "").lower()
    return name.endswith(".apk")
# ------------------------------------------------------------- .loc buyrug'i --
# Egasi haqiqiy suhbatdagi (masalan mijoz bilan) xabarga ".loc Toshkent" yoki
# ".loc 41.31, 69.24" deb yozib javob bersa, o'sha chatga lokatsiya yuboriladi.
# Bu — oddiy, zararsiz qulaylik funksiyasi (jo'natuvchining o'zi o'z joyini
# ulashmoqchi bo'lgani uchun).
_LOC_COORD_RE = re.compile(r"^\s*(-?\d{1,3}(?:\.\d+)?)\s*[,\s]\s*(-?\d{1,3}(?:\.\d+)?)\s*$")
async def _geocode_place(name: str):
    """Shahar/joy nomini OpenStreetMap (Nominatim) orqali lat/lng'ga
    aylantiradi. API kaliti kerak emas, lekin User-Agent talab qilinadi."""
    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            resp = await client.get(
                "https://nominatim.openstreetmap.org/search",
                params={"format": "json", "q": name, "limit": 1},
                headers={"User-Agent": "ArdoChatBot/1.0 (Telegram business bot)"},
            )
            resp.raise_for_status()
            data = resp.json()
            if data:
                return float(data[0]['lat']), float(data[0]['lon'])
    except Exception as e:
        logger.warning("Geokodlash xato (%s): %s", name, e)
    return None, None
async def _handle_ok_command(context, connection_id: str, owner, msg):
    """Egasi suhbatdosh xabariga javob qilib `.ok` yozganda ishga tushadi.
    Jawab qilingan xabar rasm/video/GIF bo'lsa — spoiler (blur) qo'yadi.
    Faqat 💎 Pro tarifida ishlaydi."""
    from telegram import InputMediaPhoto, InputMediaVideo, InputMediaAnimation
    # Pro tekshiruvi (soat_enabled Pro'da True, Start'da False)
    if not owner.has_feature("soat_enabled"):
        try:
            await context.bot.send_message(
                chat_id=owner.user_id,
                text=(
                    "🔒 <b>.ok</b> buyrug'i faqat <b>💎 Pro</b> tarifda mavjud.\n\n"
                    "Pro tarifga o'tib, suhbatdosh yuborgan rasmlarga "
                    "spoiler qo'ying!"
                ),
                parse_mode="HTML",
            )
        except Exception:
            pass
        return
    rtm = msg.reply_to_message
    if rtm is None:
        try:
            await context.bot.send_message(
                chat_id=owner.user_id,
                text=(
                    "⚠️ <b>.ok</b> ni ishlatish uchun biror xabarga "
                    "<b>javob</b> qilib yozing.\n\n"
                    "Qo'llab-quvvatlanadi: 🖼 Rasm · 🎥 Video · 🎞 GIF"
                ),
                parse_mode="HTML",
            )
        except Exception:
            pass
        return
    # Media turini aniqlaymiz — HAQIQIY InputMedia* obyekti yaratamiz
    # (Bot API `edit_message_media` uchun `media` doim InputMedia bo'lishi
    # kerak, JSON string EMAS — string yuborish 'str' object has no
    # attribute '_unfrozen' degan xatolikka olib kelardi, chunki
    # python-telegram-bot ichki `_insert_defaults()` funksiyasi "media"
    # kalitini string emas, InputMedia ro'yxati deb kutadi).
    if rtm.photo:
        file_id = rtm.photo[-1].file_id
        media_obj = InputMediaPhoto(media=file_id, has_spoiler=True)
        label = "🖼 Rasm"
    elif rtm.video:
        file_id = rtm.video.file_id
        media_obj = InputMediaVideo(media=file_id, has_spoiler=True)
        label = "🎥 Video"
    elif rtm.animation:
        file_id = rtm.animation.file_id
        media_obj = InputMediaAnimation(media=file_id, has_spoiler=True)
        label = "🎞 GIF"
    else:
        try:
            await context.bot.send_message(
                chat_id=owner.user_id,
                text=(
                    "⚠️ Bu xabar turini spoiler qilib bo'lmaydi.\n"
                    "Faqat 🖼 Rasm · 🎥 Video · 🎞 GIF spoilerlanadi."
                ),
            )
        except Exception:
            pass
        return
    try:
        await context.bot.edit_message_media(
            business_connection_id=connection_id,
            chat_id=msg.chat_id,
            message_id=rtm.message_id,
            media=media_obj,
        )
        try:
            await context.bot.send_message(
                chat_id=owner.user_id,
                text=f"✅ {label} spoiler qilindi.",
            )
        except Exception:
            pass
    except Exception as e:
        err = str(e).lower()
        if "not modified" in err:
            pass
        else:
            hint = ""
            if "can't be edited" in err or "not found" in err:
                hint = "\n\n<i>Eslatma: Faqat suhbatdosh yuborgan xabarlarda ishlaydi.</i>"
            try:
                await context.bot.send_message(
                    chat_id=owner.user_id,
                    text=f"⚠️ Xatolik: {e}{hint}",
                    parse_mode="HTML",
                )
            except Exception:
                pass
async def _handle_owner_loc_command(context: ContextTypes.DEFAULT_TYPE, connection_id: str,
                                     chat_id: int, owner, arg: str):
    arg = arg.strip()
    if not arg:
        try:
            await context.bot.send_message(
                chat_id=owner.user_id,
                text=(
                    "\U0001f4cd <b>.loc</b> — lokatsiya yuborish.\n"
                    "Ishlatish: suhbatda <code>.loc Toshkent</code> yoki "
                    "<code>.loc 41.31, 69.24</code> deb yozing."
                ),
                parse_mode="HTML",
            )
        except Exception:
            pass
        return
    lat = lng = None
    m = _LOC_COORD_RE.match(arg)
    if m:
        try:
            lat_c, lng_c = float(m.group(1)), float(m.group(2))
            if -90 <= lat_c <= 90 and -180 <= lng_c <= 180:
                lat, lng = lat_c, lng_c
        except ValueError:
            pass
    if lat is None:
        lat, lng = await _geocode_place(arg)
    if lat is None:
        try:
            await context.bot.send_message(
                chat_id=owner.user_id,
                text=f"\u26a0\ufe0f \u201c{_html.escape(arg)}\u201d joylashuvi topilmadi.",
                parse_mode="HTML",
            )
        except Exception:
            pass
        return
    try:
        await context.bot.send_location(
            business_connection_id=connection_id,
            chat_id=chat_id,
            latitude=lat,
            longitude=lng,
        )
    except Exception as e:
        logger.warning(".loc lokatsiya yuborilmadi: %s", e)
        try:
            await context.bot.send_message(
                chat_id=owner.user_id,
                text="\u26a0\ufe0f Lokatsiya yuborilmadi, birozdan so'ng qayta urinib ko'ring.",
            )
        except Exception:
            pass
async def on_business_connection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Foydalanuvchi botni ulaganda yoki uzganda shu yerga keladi."""
    bc = update.business_connection
    user_id = bc.user.id
    user = storage.get(user_id, bc.user.first_name)
    if bc.is_enabled:
        storage.set_business_connection(user_id, bc.id)
        if not user.settings.online_24_7:
            # Ulanganda avto-javob birdaniga ishlab tursin — foydalanuvchi
            # xohlasa Sozlamalar > 24/7 online orqali keyin o'chiradi.
            user.settings.online_24_7 = True
            storage.save(user)
        logger.info("Business ulandi: user=%s connection_id=%s", user_id, bc.id)
        await context.bot.send_message(
            chat_id=user_id,
            text=(
                "\u2705 <b>ArdoChat Bot muvaffaqiyatli ulandi!</b>\n\n"
                "Endi sizga yozgan odamlarga avto-javoblar yuboriladi. Avto "
                "javoblarni <code>.add matn</code> orqali qo'shishingiz yoki "
                "avto-javob rejimini <b>Sozlamalar > Chatbotni sozlash</b> "
                "orqali o'zgartirishingiz mumkin."
            ),
            parse_mode="HTML",
        )
        # Menyuni darhol yangilangan holatda (endi "Botni ulash" tugmasisiz,
        # o'rniga "Buyruqlar" tezkor tugmasi bilan) yangi xabar sifatida
        # yuboramiz — eski /start xabari o'zi avtomatik yangilanmaydi, shuning
        # uchun foydalanuvchi darhol yangi holatni ko'rishi uchun yangi xabar
        # jo'natamiz.
        fresh = storage.get(user_id)
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text=texts.welcome_text(fresh.first_name or bc.user.first_name, connected=True),
                reply_markup=keyboards.main_menu_kb(True, is_admin=(ADMIN_ID is not None and user_id == ADMIN_ID)),
                parse_mode="HTML",
            )
        except Exception:
            pass
    else:
        storage.clear_connection_everywhere(bc.id)
        logger.info("Business uzildi: user=%s connection_id=%s", user_id, bc.id)
async def on_business_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ulangan biznes-hisobga kimdir yozganda shu yerga keladi."""
    msg = update.business_message
    connection_id = msg.business_connection_id
    owner = storage.find_user_by_connection(connection_id)
    if owner is None:
        return  # bu ulanish bizning bazamizda yo'q (masalan, eskirgan)
    is_from_owner = bool(msg.from_user and msg.from_user.id == owner.user_id)
    # «O'chirilgan xabar» update'ida kimdan kelgani ko'rinmaydi — shuning
    # uchun bu yerda oldindan eslab qolamiz (delete_notify uchun kerak).
    _cache_owner_flag(connection_id, msg.message_id, is_from_owner)
    # 🤖 APK avtomatik o'chirish: faqat SUHBATDOSHDAN kelgan .apk fayllar.
    if not is_from_owner and owner.settings.apk_autodelete and _is_apk(msg):
        deleted = await _try_delete_apk(context, owner, connection_id, msg)
        if deleted:
            return  # xabar o'chirildi — boshqa hech narsa qilmaymiz
    # 🕵️ Shpion rejimi: Telegram bu update'ni foydalanuvchi xabarni
    # telefonida hali ochib ulgurishidan qat'i nazar, xabar kelishi
    # bilanoq yuboradi — shuning uchun shu yerda darhol botga nusxa
    # qilib jo'natish "hali o'qilmagan xabarni ko'rsatish" vazifasini
    # bajaradi. Faqat SUHBATDOSHDAN (egasi emas) kelgan xabarlar uchun.
    if owner.settings.spy_mode and not is_from_owner:
        await _spy_forward(context, owner, msg)
    # Egasi o'zi haqiqiy suhbatda ".loc ..." deb yozsa — lokatsiya yuboramiz.
    if is_from_owner and msg.text:
        stripped = msg.text.strip()
        low = stripped.lower()
        if low == ".loc" or low.startswith(".loc "):
            await _handle_owner_loc_command(context, connection_id, msg.chat_id, owner, stripped[4:])
            return
        if low == ".ok" or low.startswith(".ok "):
            await _handle_ok_command(context, connection_id, owner, msg)
            return
    # Egasi o'zi yozgan xabarlarga (masalan telefonidan) javob qaytarmaymiz.
    # Lekin egasi shu suhbatga shaxsan javob yozgani uchun — "faqat 1 marta"
    # belgisini shu suhbat uchun tozalaymiz, shunda suhbatdosh keyingi safar
    # yozganda avto-javob yana (bir marta) ishlaydi.
    if is_from_owner:
        await owner_reply_seen(owner.user_id, msg.chat_id)
        return
    # «🟢 24/7 online» — bosh o'chirgich: o'chirilgan bo'lsa, umuman
    # avtomatik javob yubormaymiz (foydalanuvchi o'zi shaxsan javob beradi).
    if not owner.settings.online_24_7:
        return
    incoming_chat_id = msg.chat_id
    incoming_text = msg.text or msg.caption or ""
    # 👥 Mijozlar: har bir suhbatdoshni kuzatib boramiz (avto-javob
    # yoqilgan-yoqilmaganidan qat'i nazar) — «Mijozlar» bo'limida ko'rish,
    # teg va izoh qo'yish uchun.
    contact_name = (msg.from_user.first_name if msg.from_user else "") or str(incoming_chat_id)
    storage.upsert_contact(owner.user_id, incoming_chat_id, contact_name)
    # «🟢 24/7 online» — bosh o'chirgich: o'chirilgan bo'lsa, umuman
    # avtomatik javob yubormaymiz (foydalanuvchi o'zi shaxsan javob beradi).
    if not owner.settings.online_24_7:
        return
    # 🔑 Kalit so'zga qarab avto-javob — umumiy avto-javoblar ro'yxatidan
    # OLDIN tekshiriladi va ish vaqti/"faqat 1 marta" cheklovidan mustasno:
    # suhbatdosh o'sha so'zni har safar yozganda mos javob qaytaveradi.
    keyword_reply = storage.find_keyword_reply(owner.user_id, incoming_text)
    reply_text = None
    if keyword_reply:
        reply_text = keyword_reply
    elif owner.auto_replies:
        reply_text = random.choice(owner.auto_replies)
    if reply_text is None and owner.settings.ok_text:
        reply_text = owner.settings.ok_text
    if reply_text is None:
        return  # avto-javob o'chirilgan (matn yo'q) — sukut saqlaymiz
    # ⏰ Ish vaqti bo'yicha avto-javob (kalit so'zli javoblarga taalluqli
    # emas — bular har doim, so'ralganda javob beraveradi).
    if keyword_reply is None and owner.settings.work_hours_enabled:
        if not _within_work_hours(owner.settings.work_hours_start, owner.settings.work_hours_end):
            if owner.settings.after_hours_text:
                reply_text = owner.settings.after_hours_text
            else:
                return  # ish vaqtidan tashqarida va alohida matn qo'yilmagan
    mode = owner.settings.autoreply_mode or "once"
    # Kalit so'zli javoblar "faqat 1 marta" cheklovidan mustasno.
    use_once = (mode == "once") and not keyword_reply
    if use_once:
        # 🔁 "Faqat 1 marta" (standart): shu suhbatdoshga avvalroq avto-javob
        # yuborilgan bo'lsa — endi jim turamiz, u yana necha marta yozsa ham.
        # Bu holat SQLite'da saqlanadi, shuning uchun bot qayta ishga
        # tushirilsa ham unutilmaydi.
        if storage.has_autoreply_sent(owner.user_id, incoming_chat_id):
            return
    else:
        # ♾️ "Har doim" / kalit so'zli javob: har xabarga javob beriladi —
        # faqat Telegram bir xil xabarni ikki marta yuborib yuborgan
        # holatning oldini olamiz.
        dedupe_key = (owner.user_id, incoming_chat_id, msg.message_id)
        if _recent_message_ids.get(dedupe_key):
            return
        _recent_message_ids[dedupe_key] = True
        _recent_message_ids.move_to_end(dedupe_key)
        while len(_recent_message_ids) > _RECENT_MESSAGE_IDS_MAX:
            _recent_message_ids.popitem(last=False)
    try:
        # ⌨️ Yozmoqda: avto-javobdan oldin bir zum "yozmoqda..." holatini
        # ko'rsatib, keyin javobni yuboramiz — tabiiyroq ko'rinishi uchun.
        if owner.settings.typing_notify:
            try:
                await context.bot.send_chat_action(
                    business_connection_id=connection_id,
                    chat_id=incoming_chat_id,
                    action="typing",
                )
                await asyncio.sleep(min(2.5, max(0.8, len(reply_text) / 40)))
            except Exception:
                pass  # "yozmoqda" ko'rsata olmasak ham, javobni baribir yuboramiz
        await context.bot.send_message(
            business_connection_id=connection_id,
            chat_id=incoming_chat_id,
            text=reply_text,
        )
        if use_once:
            storage.mark_autoreply_sent(owner.user_id, incoming_chat_id)
    except Exception as e:
        logger.warning("Business avto-javob yuborilmadi: %s", e)
async def _try_delete_apk(context: ContextTypes.DEFAULT_TYPE, owner, connection_id: str, msg) -> bool:
    """.apk faylni business ulanish orqali o'chirishga urinadi. Bunga
    Telegram tomonidan botga «Xabarlarni o'chirish» (can_delete_all_messages)
    huquqi berilgan bo'lishi kerak (ulash paytida beriladi)."""
    try:
        await context.bot.delete_business_messages(
            business_connection_id=connection_id,
            message_ids=[msg.message_id],
        )
    except Exception as e:
        logger.warning("APK o'chirilmadi user=%s: %s", owner.user_id, e)
        try:
            await context.bot.send_message(
                chat_id=owner.user_id,
                text=(
                    "\u26a0\ufe0f Kimdir sizga .apk fayl yubordi, lekin uni "
                    "avtomatik o'chirishga urinish muvaffaqiyatsiz bo'ldi. "
                    "Botni ulaganingizda Telegram Business sozlamalarida bu "
                    "botga <b>\"Xabarlarni o'chirish\"</b> huquqini "
                    "berganingizga ishonch hosil qiling."
                ),
                parse_mode="HTML",
            )
        except Exception:
            pass
        return False
    try:
        name = _html.escape(msg.document.file_name or "noma'lum")
        await context.bot.send_message(
            chat_id=owner.user_id,
            text=(
                f"\U0001f6e1\ufe0f <b>APK fayl avtomatik o'chirildi</b>\n"
                f"\U0001f464 Kimdan: {_html.escape(_sender_label(msg))}\n"
                f"\U0001f4c4 Fayl nomi: <code>{name}</code>"
            ),
            parse_mode="HTML",
        )
    except Exception:
        pass
    return True
async def on_edited_business_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Suhbatdosh o'ziga yuborilgan (yoki egasi o'ziga kelgan) xabarni
    tahrirlaganda shu yerga keladi."""
    msg = update.edited_business_message
    connection_id = msg.business_connection_id
    owner = storage.find_user_by_connection(connection_id)
    if owner is None:
        return
    is_from_owner = bool(msg.from_user and msg.from_user.id == owner.user_id)
    _cache_owner_flag(connection_id, msg.message_id, is_from_owner)
    # Faqat SUHBATDOSH tahrirlaganda javob beramiz — egasi o'zi
    # tahrirlasa, hech narsa yubormaymiz.
    if is_from_owner or not owner.settings.edit_notify:
        return
    if not owner.settings.edit_notify_text:
        return
    chat_id = msg.chat_id
    if not _notify_allowed(owner.user_id, chat_id, "edit"):
        return
    try:
        await context.bot.send_message(
            business_connection_id=connection_id,
            chat_id=chat_id,
            text=owner.settings.edit_notify_text,
        )
    except Exception as e:
        logger.warning("Tahrirlash bildirishnomasi yuborilmadi: %s", e)
async def on_deleted_business_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Suhbatdosh o'zi yuborgan xabarni o'chirganda shu yerga keladi."""
    dbm = update.deleted_business_messages
    connection_id = dbm.business_connection_id
    owner = storage.find_user_by_connection(connection_id)
    if owner is None:
        return
    if not owner.settings.delete_notify or not owner.settings.delete_notify_text:
        for mid in dbm.message_ids:
            _pop_owner_flag(connection_id, mid)
        return
    # Bitta o'chirish hodisasida bir nechta xabar id kelishi mumkin — agar
    # ular orasida hech bo'lmaganda bittasi suhbatdoshniki bo'lsa, bitta
    # bildirishnoma yuboramiz (spam qilmaslik uchun).
    any_from_interlocutor = False
    for mid in dbm.message_ids:
        is_owner_msg = _pop_owner_flag(connection_id, mid)
        if not is_owner_msg:
            any_from_interlocutor = True
    if not any_from_interlocutor:
        return
    chat_id = dbm.chat.id
    if not _notify_allowed(owner.user_id, chat_id, "delete"):
        return
    try:
        await context.bot.send_message(
            business_connection_id=connection_id,
            chat_id=chat_id,
            text=owner.settings.delete_notify_text,
        )
    except Exception as e:
        logger.warning("O'chirish bildirishnomasi yuborilmadi: %s", e)
async def owner_reply_seen(owner_id: int, chat_id: int):
    """Egasi shu suhbatga o'zi shaxsan (telefonidan) javob yozganda
    chaqiriladi — "faqat 1 marta" belgisini shu suhbat uchun tozalaydi,
    shunda kelasi safar suhbatdosh yozganda avto-javob yana ishlaydi
    (chunki egasi o'zi allaqachon shaxsan javob bergan, demak yangi
    "birinchi xabar" holati boshlangan hisoblanadi)."""
    storage.reset_autoreply_sent(owner_id, chat_id)
def _within_work_hours(start: str, end: str) -> bool:
    """"HH:MM"-"HH:MM" oralig'ida hozirgi vaqt bormi, tekshiradi. Agar
    end < start bo'lsa (masalan 22:00–06:00), kechayarim orqali o'tuvchi
    oraliq deb hisoblanadi. Noto'g'ri formatda xato chiqmasin uchun har
    doim "ish vaqtida" deb qaytaramiz (xavfsiz yo'l tutish)."""
    try:
        now = datetime.now().time()
        sh, sm = (int(x) for x in start.split(":"))
        eh, em = (int(x) for x in end.split(":"))
        start_t, end_t = time_cls(sh, sm), time_cls(eh, em)
    except (ValueError, AttributeError):
        return True
    if start_t <= end_t:
        return start_t <= now <= end_t
    return now >= start_t or now <= end_t
def _sender_label(msg) -> str:
    if not msg.from_user:
        return "Noma'lum"
    name = msg.from_user.full_name or msg.from_user.first_name or "Noma'lum"
    if msg.from_user.username:
        return f"{name} (@{msg.from_user.username})"
    return name
async def _spy_forward(context: ContextTypes.DEFAULT_TYPE, owner, msg):
    """Shpion rejimi yoqilganda kelgan xabarning (matn/rasm/video/...) 
    nusxasini egasiga botning o'zi orqali yuboradi."""
    header = f"\U0001f575\ufe0f <b>Yashirin nusxa</b>\n\U0001f464 Kimdan: {_html.escape(_sender_label(msg))}\n\n"
    body_caption = _html.escape(msg.caption or "")
    body_text = _html.escape(msg.text or "")
    try:
        if msg.photo:
            await context.bot.send_photo(
                chat_id=owner.user_id,
                photo=msg.photo[-1].file_id,
                caption=(header + body_caption).strip(),
                parse_mode="HTML",
            )
        elif msg.video:
            await context.bot.send_video(
                chat_id=owner.user_id,
                video=msg.video.file_id,
                caption=(header + body_caption).strip(),
                parse_mode="HTML",
            )
        elif msg.video_note:
            await context.bot.send_message(chat_id=owner.user_id, text=header, parse_mode="HTML")
            await context.bot.send_video_note(chat_id=owner.user_id, video_note=msg.video_note.file_id)
        elif msg.voice:
            await context.bot.send_voice(
                chat_id=owner.user_id,
                voice=msg.voice.file_id,
                caption=header,
                parse_mode="HTML",
            )
        elif msg.animation:
            await context.bot.send_animation(
                chat_id=owner.user_id,
                animation=msg.animation.file_id,
                caption=(header + body_caption).strip(),
                parse_mode="HTML",
            )
        elif msg.document:
            await context.bot.send_document(
                chat_id=owner.user_id,
                document=msg.document.file_id,
                caption=(header + body_caption).strip(),
                parse_mode="HTML",
            )
        elif msg.sticker:
            await context.bot.send_message(chat_id=owner.user_id, text=header, parse_mode="HTML")
            await context.bot.send_sticker(chat_id=owner.user_id, sticker=msg.sticker.file_id)
        elif msg.text:
            await context.bot.send_message(
                chat_id=owner.user_id,
                text=header + body_text,
                parse_mode="HTML",
            )
        else:
            await context.bot.send_message(
                chat_id=owner.user_id,
                text=header + "<i>(qo'llab-quvvatlanmaydigan turdagi xabar)</i>",
                parse_mode="HTML",
            )
    except Exception as e:
        logger.warning("Shpion nusxasi yuborilmadi: %s", e)
