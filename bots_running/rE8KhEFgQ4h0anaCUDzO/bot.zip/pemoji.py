"""
ArdoChat Bot — «Premium emoji» tizimi.

MUHIM CHEKLOV (halol ogohlantirish): Telegram Bot API inline TUGMALARI
(InlineKeyboardButton) faqat oddiy matnni qo'llab-quvvatlaydi — tugma
ustidagi yozuvda HECH QANDAY formatlash yoki custom/premium emoji bo'lishi
MUMKIN EMAS (bu Telegram platformasining o'zi qo'ygan cheklov, botda emas).
Shuning uchun premium emoji faqat botning ODDIY MATNLARIDA (xabar matni,
tugmalar TEPASIDAGI yozuvlarda) ishlaydi — tugmaning o'zida emas.

Ishlash prinsipi: admin panel orqali "oddiy emoji -> premium custom_emoji_id"
moslamasi saqlanadi (storage.premium_emoji_map). Botning deyarli barcha
matnlari texts.py orqali generatsiya qilingani uchun, shu modul orqali har
bir matn chiqishidan oldin avtomatik ravishda tekshirilib, agar matnda shu
oddiy emoji uchrasa — Telegram HTML'ning maxsus <tg-emoji emoji-id="..">
tegi bilan o'raladi (parse_mode=HTML bilan ishlaydi). Premium emoji'ni
YO'Q foydalanuvchilar oddiy (fallback) emoji'ni ko'radi — hech narsa
buzilmaydi.
"""
import re

_cache: dict | None = None


def invalidate_cache():
    global _cache
    _cache = None


def _map() -> dict:
    global _cache
    if _cache is None:
        from storage import storage
        _cache = storage.get_premium_emoji_map()
    return _cache


_TAG_SPLIT_RE = re.compile(r"(<[^>]+>)")


def wrap(text: str) -> str:
    """Matndagi barcha moslashtirilgan emojilarni <tg-emoji> tegi bilan
    o'raydi. HTML teglari ichiga (masalan atributlarga) tegmaslik uchun
    matn avval teglar bo'yicha bo'lakларга ажратилади, faqat teg BO'LMAGAN
    bo'laklarda almashtirish qilinadi."""
    if not text:
        return text
    mapping = _map()
    if not mapping:
        return text
    parts = _TAG_SPLIT_RE.split(text)
    for i, part in enumerate(parts):
        if part.startswith("<") and part.endswith(">"):
            continue  # bu HTML teg — tegmaymiz
        for emoji_char, custom_id in mapping.items():
            if emoji_char and emoji_char in part:
                part = part.replace(
                    emoji_char,
                    f'<tg-emoji emoji-id="{custom_id}">{emoji_char}</tg-emoji>',
                )
        parts[i] = part
    return "".join(parts)


# Botning matnlarida uchraydigan asosiy emojilar ro'yxati — admin panelda
# "qaysi emojini premium qilaman" deb tanlash uchun ko'rsatiladi. To'liq
# unicode-emoji regex ishlatilmadi (noto'g'ri chegaralarga tushib qolmasligi
# uchun), o'rniga botda haqiqatan ishlatiladigan emojilar aniq ro'yxat
# qilib berilgan — shu yerga yangi emoji qo'shsangiz, admin panelda ham
# avtomatik chiqadi.
KNOWN_EMOJIS = [
    "🤖", "👋", "❔", "❓", "🔗", "📘", "🧾", "👤", "⚙️", "💬", "👥", "📱",
    "⏰", "🟢", "🕵️", "🐥", "✏️", "🗑", "🤖", "⌨️", "🔑", "💳", "⭐", "💰",
    "📊", "📈", "🚫", "⏳", "📢", "✅", "❌", "⚠️", "🔥", "🎛", "🏷", "🆓",
    "💎", "🔁", "♻️", "🌙", "🕘", "📍", "✉️", "🎨", "🛡️", "🔐", "🔒",
    "👑", "🔂", "♾️", "📄", "🎞", "🕰", "👀", "📝", "🆕",
]
