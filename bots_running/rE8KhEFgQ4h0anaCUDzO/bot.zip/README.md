# 🦆 ArdoChat Bot — TO'LIQ ISHLAYDIGAN versiya

## 🆕 Oxirgi yangilanish

- **⏰ "Profilga soat" muzlab qolish muammosi tuzatildi.** Sabab: bot ismni
  har 60 soniyada o'zgartirishga urinardi, bu esa Telegram tomonidan juda
  tez-tez deb hisoblanib uzoq muddatli FloodWait cheklovga sabab bo'lardi.
  Endi standart interval 5 daqiqaga oshirildi va FloodWait boshlanganda/
  tugaganda foydalanuvchiga **avtomatik xabar** boradi (nega to'xtaganini
  va qachon davom etishini aytadi) — endi sababsiz "ishlamay qoldi" deb
  o'ylamaysiz.
- **AI bo'limi butunlay olib tashlandi** — `.ai` buyrug'i va unga
  bog'liq sozlamalar yo'q endi.
- **Avto-javob standart holatda FAQAT 1 marta** yuboriladi (suhbatdosh
  necha marta yozsa ham). Sozlamalar → 🐥 Chatbotni sozlash orqali "Har
  doim" rejimiga o'tkazish yoki xotirani tozalash mumkin.
- **👥 Mijozlar bo'limi** — sizga yozgan har bir odam avtomatik ro'yxatga
  tushadi (Bosh menyu → 👥 Mijozlar). Har biriga teg (🆕/🔥/😴/⭐ VIP) va
  izoh qo'yish mumkin.
- **🔑 Kalit so'zli avto-javoblar** — masalan "narx" so'zi kelsa, maxsus
  javob avtomatik yuboriladi (Sozlamalar → 🐥 Chatbotni sozlash → 🔑 Kalit
  so'zli javoblar). Bu javoblar "1 marta" cheklovidan mustasno — har safar
  ishlaydi.
- **⏰ Ish vaqti bo'yicha avto-javob** — masalan faqat 09:00–18:00
  oralig'ida oddiy avto-javob, undan tashqarida alohida matn ("Ish vaqti
  tugadi, ertaga javob beramiz" kabi) yuborish mumkin.
- **🛠 Admin panel kengaytirildi** (`/admin`): to'liq statistika, 📈
  bugungi hisobot, 🧾 admin harakatlari logi, 👥 foydalanuvchilarni ID
  orqali boshqarish (balans qo'shish, bloklash, avto-javob xotirasini
  tozalash), 🚫 bloklanganlar ro'yxati.

Bu endi demo emas. Uch qism ham HAQIQIY ishlaydi:

1. **Doimiy ma'lumot** — SQLite (`ardochat.db`). Bot qayta ishga tushirilsa
   ham foydalanuvchi, balans, tarif, avto javoblar, business ulanish —
   hech narsa yo'qolmaydi. (JSON fayl ishlatilmagan, talab bo'yicha.)

2. **HAQIQIY Telegram Business avto-javob** — foydalanuvchi telefonida
   Sozlamalar → Telegram Business → Chatbots → botni qo'shsa, Telegram
   bizga `business_connection` va `business_message` update yuboradi va
   biz `send_message(business_connection_id=...)` orqali xuddi o'sha
   odam nomidan haqiqiy avto-javob yozamiz (`business.py`).
   *(Telegram Business — Telegram Premium talab qiladigan funksiya —
   bu Telegram'ning cheklovi, botga bog'liq emas.)*

3. **HAQIQIY to'lovlar** (`payments.py`):
   - **Telegram Stars** — hech qanday sozlash kerak emas, darhol ishlaydi.
   - **Click/Payme karta to'lovi** — `.env`dagi `PAYMENT_PROVIDER_TOKEN`ni
     to'ldirsangiz (BotFather → Payments → Click/Payme ulash), to'lov
     to'liq avtomatik.
   - Token bo'lmasa — karta raqami ko'rsatiladi, admin real vaqtda
     tugma bosib tasdiqlaydi, balans SQLite'ga darhol yoziladi.

4. **HAQIQIY "Profilga soat"** (`profile_clock.py`) — akkaunt ismiga
   jonli soat qo'shadi, 6 xil shrift uslubi va ajratuvchi «|» bilan.
   **Muhim:** oddiy Bot API bilan bot hech qachon foydalanuvchining o'z
   profil ismini o'zgartira olmaydi — bu Telegram cheklovi. Shuning uchun
   bu funksiya Telethon orqali **sizning o'z hisobingiz nomidan** ishlaydi
   (userbot) va faollashtirish uchun bir marta telefon raqami + tasdiqlash
   kodi so'raladi. Ishga tushirish uchun `.env`ga `TELEGRAM_API_ID` va
   `TELEGRAM_API_HASH` (https://my.telegram.org — bepul) qo'shilishi kerak;
   bo'lmasa, tugma bosilganda tushunarli ogohlantirish chiqadi va botning
   qolgan qismi baribir to'liq ishlayveradi.

5. **"🟢 24/7 online" ENDI HAQIQIY ISHLAYDI** — avval bu tugma faqat
   bazaga yozilar, lekin hech narsaga ta'sir qilmasdi. Endi: o'chirilgan
   bo'lsa avto-javob/AI umuman yuborilmaydi (siz shaxsan javob berasiz),
   yoqilgan bo'lsa — doimiy avtomatik javob beriladi. Botni ulaganingizda
   avtomatik yoqiladi, xohlasangiz Sozlamalar orqali o'chirasiz.

## Tuzilma

```
ardochat_bot/
├── bot.py            # ishga tushirish, barcha handlerlarni ro'yxatga oladi
├── config.py          # .env'dan sozlamalar
├── storage.py          # SQLite — doimiy saqlash
├── business.py         # HAQIQIY Telegram Business avto-javob
├── payments.py          # HAQIQIY to'lovlar (Stars / Click / Payme / admin)
├── profile_clock.py      # HAQIQIY "Profilga soat" (Telethon userbot)
├── texts.py             # barcha o'zbek matnlari
├── keyboards.py          # inline tugmalar
├── handlers.py           # /start, menyu, profil, balans, sozlamalar
├── dotcommands.py         # .ai .dice .add .list .clear .settings va h.k.
├── requirements.txt
├── .env.example
└── README.md
```

## O'rnatish

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
```

`.env` faylida quyidagilarni to'ldiring:

| O'zgaruvchi | Majburiymi | Izoh |
|---|---|---|
| `BOT_TOKEN` | ✅ Ha | @BotFather'dan olinadi |
| `BOT_USERNAME` | ✅ Ha | bot username'i (@ belgisiz) |
| `ADMIN_ID` | ✅ Tavsiya etiladi | karta to'lovlarini tasdiqlash, statistikani ko'rish uchun. Botga `/myid` yozib bilib olasiz |
| `PAYMENT_PROVIDER_TOKEN` | Ixtiyoriy | Click/Payme avtomatik to'lov uchun |
| `OPENAI_API_KEY` | Ixtiyoriy | `.ai` buyrug'i haqiqiy ChatGPT javob bersin desangiz |
| `CARD_NUMBER`, `CARD_OWNER` | Ixtiyoriy | provider token yo'q bo'lganda ko'rsatiladigan karta |
| `TELEGRAM_API_ID`, `TELEGRAM_API_HASH` | Ixtiyoriy | "Profilga soat" funksiyasi uchun — https://my.telegram.org |

## Ishga tushirish

```bash
python bot.py
```

## Admin buyruqlari

- `/myid` — o'z Telegram ID'ingizni ko'rish (buni `.env`ga `ADMIN_ID` qilib qo'ying)
- `/admin_stats` — umumiy statistikani ko'rish (faqat admin)
- `/credit <user_id> <summa>` — foydalanuvchiga qo'lda balans qo'shish (faqat admin)

## Muhim eslatmalar

- Telegram Business funksiyasi ishlashi uchun ulovchi foydalanuvchining
  **Telegram Premium** obunasi bo'lishi shart — bu Telegram tomonidan
  qo'yilgan talab, kodning cheklovi emas. Shu shart bajarilsa, ushbu bot
  haqiqatan ham avto-javoblarni suhbatdoshlarga jo'natadi.
- "Profilga soat" login jarayonida saqlanadigan Telethon sessiyasi —
  sizning hisobingizga to'liq kirish huquqi bilan teng kuchga ega.
  Bazani (`ardochat.db`) va serverni faqat o'zingiz ishonadigan joyda
  saqlang, hech kim bilan bo'lishmang.
- Bu kod sandbox muhitida (tarmoqqa chiqish yo'q) haqiqiy Telegram
  serverlariga ulanmasdan sinovdan o'tkazildi (barcha modullar soxta
  `telegram`/`telethon` stub'lari bilan import qilinib, mantiq
  tekshirildi). Ishga tushirishdan oldin haqiqiy tokenlar bilan bir marta
  qo'lda sinab ko'rishni tavsiya qilaman — ayniqsa "Profilga soat" login
  oqimini.
