"""
ArdoChat Bot — «Shpion rejimi» (HAQIQIY, Telethon userbot orqali).

G'oyasi: kimdir sizga (sizning shaxsiy Telegram akkountingizga) xabar
yozadi — matn, rasm yoki video. Agar siz hali o'sha xabarni OCHIB
o'qimasdan turib, yuboruvchi o'zi uni o'chirib tashlasa — oddiy holatda bu
xabar siz uchun butunlay yo'qoladi. Shpion rejimi yoqilganda, xabar
o'chirilishidan OLDINGI holatini ArdoChat botiga (sizning haqiqiy
akkountingiz nomidan) yuborib ulguradi, xuddi o'zingiz forward
qilgandek.

Texnik asos: oddiy Bot API begona odamlarning sizga yozgan shaxsiy
xabarlarini "orqadan" o'qiy olmaydi — bu faqat sizning akkountingiz
nomidan ishlaydigan Telethon mijozi (userbot) orqali mumkin. Shu sabab bu
funksiya «Profilga soat» bilan BIR XIL login sessiyasidan foydalanadi —
agar u orqali allaqachon tasdiqlangan bo'lsangiz, qayta login kerak emas.

MUHIM CHEKLOVLAR (halol ogohlantirish, "sehr" emas):
  1) Xabarlar bazaga emas, faqat XOTIRADA, TTL (standart 10 daqiqa) muddat
     bilan saqlanadi. Shu muddat ichida o'chirilmasa — keshdan o'chib
     ketadi (xotira cheksiz o'smasligi uchun) va endi qayta tiklab
     bo'lmaydi. Bot qayta ishga tushirilsa ham kesh tozalanadi.
  2) Telegram'ning "delete" update'i qaysi suhbatdan ekanini har doim
     aniq ko'rsatmaydi (bu Telegram protokolining o'zining cheklovi),
     shuning uchun moslik xabar ID'si bo'yicha amalga oshiriladi.
  3) Bu — boshqa odamning yozgan xabarini ularning roziligisiz saqlab
     qolish demakdir. O'zingiz va suhbatdoshlaringiz o'rtasidagi qonuniy
     va axloqiy javobgarlik sizning zimmangizda; yashirin kuzatuv taqiqlangan
     joylarda ishlatmang.
"""
import logging
import time
from collections import defaultdict

from config import TELEGRAM_API_ID, TELEGRAM_API_HASH, BOT_USERNAME

logger = logging.getLogger(__name__)

TELETHON_AVAILABLE = True
try:
    from telethon import events
    from telethon.errors import UnauthorizedError
except ImportError:  # telethon requirements.txt orqali o'rnatilmagan bo'lishi mumkin
    TELETHON_AVAILABLE = False

    class UnauthorizedError(Exception):
        pass

CACHE_TTL_SECONDS = 10 * 60  # 10 daqiqa — shundan keyin kesh avtomatik tozalanadi

# user_id -> {message_id: {...}}  — hali "xavfsiz" (o'chirilmagan) kiruvchi xabarlar
_pending: dict[int, dict[int, dict]] = defaultdict(dict)

# Qaysi user_id lar uchun Telethon event handler allaqachon ulanganini
# saqlaymiz — bir xil handler ikki marta qo'shilib ketmasligi uchun.
_registered: set[int] = set()


def spy_configured() -> bool:
    return TELETHON_AVAILABLE and bool(TELEGRAM_API_ID) and bool(TELEGRAM_API_HASH)


def _purge_expired(user_id: int):
    now = time.time()
    bucket = _pending[user_id]
    expired = [mid for mid, item in bucket.items() if now - item['ts'] > CACHE_TTL_SECONDS]
    for mid in expired:
        bucket.pop(mid, None)


async def _forward_to_bot(client, item: dict, deleted: bool = False):
    kind = "🎞 Media" if item['media_bytes'] else "✏️ Matn"
    title = "🗑 O'CHIRILGAN XABAR (nusxasi)" if deleted else "🕵️ Yangi xabar (jonli nusxa)"
    header = (
        f"{title}\n"
        f"👤 Kimdan: {item['sender_name']} (id: {item['sender_id']})\n"
        f"📌 Turi: {kind}\n"
        "—"
    )
    caption = header + (("\n" + item['text']) if item['text'] else "")
    target = f"@{BOT_USERNAME}"
    try:
        if item['media_bytes'] is not None:
            await client.send_file(target, item['media_bytes'], caption=caption[:1024])
        else:
            await client.send_message(target, caption[:4000])
    except UnauthorizedError:
        raise
    except Exception as e:
        logger.warning("Spy: ArdoChat botiga yuborib bo'lmadi: %s", e)


def _make_handlers(storage_module, user_id: int):
    async def on_new_message(event):
        if not event.is_private or event.out:
            return  # faqat sizga kelgan shaxsiy xabarlar bilan ishlaymiz
        user = storage_module.storage.get(user_id)
        if not user.settings.spy_mode:
            return
        _purge_expired(user_id)
        try:
            sender = await event.get_sender()
            sender_name = (
                getattr(sender, "first_name", None)
                or getattr(sender, "username", None)
                or str(event.sender_id)
            )
        except Exception:
            sender_name = str(event.sender_id)

        media_bytes = None
        if event.media:
            try:
                media_bytes = await event.download_media(bytes)
            except Exception as e:
                logger.warning("Spy: media yuklab olinmadi: %s", e)

        item = {
            "sender_name": sender_name,
            "sender_id": event.sender_id,
            "text": event.raw_text or "",
            "media_bytes": media_bytes,
            "ts": time.time(),
        }
        # Keshda saqlaymiz (keyin o'chirilsa, xabar "o'chirilgan" belgisi
        # bilan yana bir marta yuboriladi) VA — foydalanuvchi so'ragani
        # bo'yicha — xabar o'chirilsa ham, o'chirilmasa ham farqsiz, DARHOL
        # botga nusxa qilib yuboramiz (business akkauntdagi Shpion rejimi
        # bilan bir xil xatti-harakat).
        _pending[user_id][event.id] = item
        try:
            await _forward_to_bot(event.client, item, deleted=False)
        except UnauthorizedError:
            import profile_clock
            await profile_clock._session_lost(storage_module, user)

    async def on_deleted(event):
        user = storage_module.storage.get(user_id)
        if not user.settings.spy_mode:
            return
        bucket = _pending[user_id]
        client = event.client
        for mid in event.deleted_ids:
            item = bucket.pop(mid, None)
            if item is None:
                continue  # keshda yo'q — yo eskirgan, yo bizniki emas
            try:
                await _forward_to_bot(client, item, deleted=True)
            except UnauthorizedError:
                import profile_clock
                await profile_clock._session_lost(storage_module, user)
                return

    return on_new_message, on_deleted


async def ensure_spy_running(storage_module, user) -> bool:
    """Berilgan foydalanuvchi uchun shpion tinglovchisini ulaydi
    (agar hali ulanmagan bo'lsa). True — muvaffaqiyatli ulangan/allaqachon
    ulangan, False — sozlanmagan yoki sessiya yo'q."""
    if not spy_configured() or not user.telethon_session:
        return False
    if user.user_id in _registered:
        return True

    import profile_clock  # aylanma import'dan qochish uchun shu yerda
    client = await profile_clock._get_client(user.user_id, user.telethon_session)
    on_new_message, on_deleted = _make_handlers(storage_module, user.user_id)
    client.add_event_handler(on_new_message, events.NewMessage(incoming=True))
    client.add_event_handler(on_deleted, events.MessageDeleted())
    _registered.add(user.user_id)
    logger.info("Spy: tinglovchi ulandi user=%s", user.user_id)
    return True


async def start_all(storage_module):
    """Bot ishga tushganda (post_init) chaqiriladi: shpion rejimi yoqilgan
    barcha foydalanuvchilar uchun tinglovchini oldindan ulab qo'yadi."""
    if not spy_configured():
        return
    for user in storage_module.storage.users_with_spy_enabled():
        try:
            await ensure_spy_running(storage_module, user)
        except Exception as e:
            logger.warning("Spy: ulanmadi user=%s: %s", user.user_id, e)
